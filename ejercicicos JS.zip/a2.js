/*
const edad = 20;
edad = 21;
console.log(edad);
*/
//me dice la edad pero peta porque hay 2 variables iguales --> bloque 1

//

/*
const alumno = { nombre: "Luis", edad: 20 };
alumno.edad = 21;
console.log(alumno.edad);
alumno = { nombre: "Marta", edad: 22 };
*/

//falla tambien, mostrando la edad y falla porque intenta cambiar una constante --> bloque 2