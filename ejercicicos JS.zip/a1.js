const modulo = "Desarrollo de interfaces";
const horas = 140;
const IVA = 0.21;
const aprobado = true;
console.log(modulo + " tiene " + horas + " horas");