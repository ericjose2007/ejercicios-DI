const nombre = "Ana"
let edad = 20;
const saludo = `Hola ${nombre}, tienes ${edad} años`; //error: comillas puestas errones, sino lo pone literalmente el texto
edad = 21;
const MAX = 3; //linea falsa, no sirve para nada
/*MAX = 5;*/ //error: Assignment to constant variable. por modificar una constante
function sumar(a, b) { //error: Unexpected identifier. tipos en js
    return a + b;
}
console.log(saludo, sumar(2, 3));