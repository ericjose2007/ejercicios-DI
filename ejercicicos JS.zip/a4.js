const alumno = {nombre: "Eric", edad: 19, ciclo: "2ºDAM", modulos: ["Programación", "Desarrollo de Interfaces", "Optativa"]};
alumno.edad = 20;
alumno.modulos.push("IPE");
console.log("Nombre: " + alumno.nombre);
console.log("Edad: " + alumno.edad);
console.log("Tiene " + alumno.modulos.length + " modulos");