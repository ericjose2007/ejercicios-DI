function doble(num) {
    return num * 2;
}

function esMayorDeEdad(edad) {
    return edad >= 18;
}

function saludar(nombre) {
    return "Hola " + nombre;
}

areaRectangulo = (base, altura) => {
    return base * altura;
}

console.log(doble(4));
console.log(esMayorDeEdad(17));
console.log(saludar("Ana"));
console.log(areaRectangulo(2,3));